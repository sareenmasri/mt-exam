jQuery(document).ready(function($){

    function loadExams(page = 1) {
        $.ajax({
            url: em_ajax_obj.ajax_url,
            type: 'POST',
            data: {
                action: 'em_get_exams',
                page: page,
                nonce: em_ajax_obj.nonce
            },
            success: function(response){
                if(response.success){
                    renderExams(response.data);
                }else{
                    $('#em-exam-list').html('<p>No exams found.</p>');
                    console.log('Error:', response.data);
                }
            },
            error: function(err){
                $('#em-exam-list').html('<p>AJAX error.</p>');
                console.log(err);
            }
        });
    }

    function renderExams(exams){
        if(!exams.length){
            $('#em-exam-list').html('<p>No exams available.</p>');
            return;
        }

        let html = '';
        exams.forEach(exam => {
            html += `
                <div class="em-exam ${exam.status}">
                    <h4>${exam.title}</h4>
                    <p>Start: ${exam.start}</p>
                    <p>End: ${exam.end}</p>
                    <p>Status: ${exam.status}</p>
                </div>
            `;
        });
        $('#em-exam-list').html(html);
    }

    loadExams();

});
